/*
 * Main_flow_sensor_laser.c
 *
 * Created: 5/20/2014 9:16:13 PM
 *  Author: Jan-Jaap
 *
 *	@4.8MHZ/8 - 600Khz
 *  Brownout @4.3v
 *	Pinout:
 *	PB0 = RF433 MHz sender
 *	PB1 = TX debug 9600 8N1, LED
 *	PB2 = INT0, for gesture chip ADPS-9960
 *	PB3 = SCL I2C ADPS-9960
 *	PB4 = SDA I2C ADPS-9960
 *	PB5 = Reset
 *
 */ 

#include <stdlib.h> 
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include <avr/pgmspace.h>
#include "dbg_putchar.h"
#include "Klikaan_klikuit.h"
#include "SparkFun_APDS9960.h"
//#include "i2csw.h"


//#define PORT_ADDR  0x39	// For APDS-9960 address
#define APDS9960_INT	PB2 // Needs to be an interrupt pin

#define FLOW_THRESHOLD 4	// Threshold of output vs. flow
#define EXT_AS_LED_SWITCH 1

/* Pinouts */
/* PB1 = serial debug TX defined in dbg_putchar.c */

// Use jumper to enable led (no TX then)
#define LED_PIN PB1
#define LED_ON	(PORTB |= (1 << LED_PIN))		// LED on
#define LED_OFF	(PORTB &= ~(1 << LED_PIN))		// LED off
#define LED_TOGGLE (PORTB ^= (1 << LED_PIN))		// LED toggle

// Prototypes
void init_IO(void);
void init_interrupt(void);
void send_start_settings(void);
void uart_puts(const char *s);				// Print strings from RAM 
void uart_puts_p(const char *progmem_s);	// Print strings from PROGMEM (FLASH)
void LED_sound(void);
void LED_alarm(void);
void my_delay_ms(uint8_t n);

uint8_t int_flag = 0;

ISR (INT0_vect)
{
	// Do something?
	//int_flag = 1;
}

int main(void)
{
	//unsigned char i2cdata[8];
	//dbg_tx_init();
	/*
	if (init_apds()) 
	{
		uart_puts("APDS-9960 initialization complete\n");
	} 
	else 
	{
		 uart_puts("Something went wrong during APDS-9960 init!\n");
	}
	*/
	//apdsInit();
	//apdsOn();
	//uart_puts("APDS9300 int done!");
	//i2cInit();	// done in sensor init
	//init_IO();
	init_klikaan_klikuit();

	
	//init_interrupt();
	send_start_settings();
	
	
	//LED_sound();	// Start l
	
	while(1) 
	{
		//flow_counter = 0;					// Reset flow counter
		//sei();							// Enable interrupts to be able to pick up rotor movement again
		//LED_TOGGLE;
		_delay_ms(10000);						// Wait 100ms to count pulses in that time	
		//PORTB ^= (1<<0);	// Make output low
		//send_klikaan_klikuit(c_on_1);
		_delay_ms(10000);	
		if (int_flag)
		{
			uart_puts("Int triggered!");
			int_flag = 0;
		}
		
		//send_klikaan_klikuit(c_off_1);
	}	
}

void init_IO(void)
{
	DDRB |= (1<<LED_PIN);					// Output pin for LED
}

void init_interrupt(void)	// int of apds9960
{
	GIMSK |= (1<<INT0);		// Enable INT0
	MCUCR |= (1<<ISC01);	// INT0 on Falling edge
	sei();					// Enable global interrupts
}	

void send_start_settings(void)
{
	uart_puts_p(PSTR("Gesture recognition APDS-9960 chip test v1.0\n"));
	uart_puts_p(PSTR("Start flow measurement, threshold = "));
	uart_puts("\n");
}

void my_delay_ms(uint8_t n) 
{
	while(n--) {
		_delay_us(1);
	}
}
